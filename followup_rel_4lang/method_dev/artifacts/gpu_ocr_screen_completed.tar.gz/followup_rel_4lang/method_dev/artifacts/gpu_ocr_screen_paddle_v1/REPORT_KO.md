# GPU OCR: Screen 비교

개발용 Screen 20문항·240 mismatch pair. 각 조건은 pilot 동반 행을 포함해 288 pair를 실행한다. OCR는 128개 화면을 처리하며 아래 주 분석 비용에는 main 화면 80개만 포함한다.

같은 E1 stem 추출·M0 정렬을 유지하고 inventory만 교체한다. 8B/4B는 OCR와 수정 질문을 공유한다. PP-OCRv5는 RapidOCR 전후처리와 Paddle Inference CUDA의 mobile detector + 언어별 mobile recognizer를 사용한다. PaddleOCR Python pipeline 전체를 실행한 것은 아니다.

| Solver | Inventory | 정답/240 | 정확도 | Inventory | 추출+정렬 | 풀이 | 총 시간 | 초/pair |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 8B | O | 162 | 67.50% | 0.00분 | 0.00분 | 2.92분 | 2.92분 | 0.730 |
| 8B | VLM_inventory | 178 | 74.17% | 29.56분 | 6.37분 | 3.17분 | 39.10분 | 9.774 |
| 8B | EasyOCR_CPU | 179 | 74.58% | 14.92분 | 6.50분 | 3.17분 | 24.59분 | 6.146 |
| 8B | easyocr_cuda | 181 | 75.42% | 0.52분 | 6.40분 | 3.23분 | 10.15분 | 2.537 |
| 8B | ppocrv5_cuda | 182 | 75.83% | 0.15분 | 6.54분 | 3.33분 | 10.02분 | 2.505 |
| 4B | O | 174 | 72.50% | 0.00분 | 0.00분 | 2.84분 | 2.84분 | 0.711 |
| 4B | VLM_inventory | 181 | 75.42% | 11.42분 | 6.22분 | 2.85분 | 20.49분 | 5.123 |
| 4B | EasyOCR_CPU | 175 | 72.92% | 14.92분 | 6.50분 | 2.92분 | 24.34분 | 6.085 |
| 4B | easyocr_cuda | 177 | 73.75% | 0.52분 | 6.40분 | 3.00분 | 9.92분 | 2.479 |
| 4B | ppocrv5_cuda | 177 | 73.75% | 0.15분 | 6.54분 | 3.09분 | 9.78분 | 2.444 |

시간은 기존 추출과 재사용한 풀이도 원래 측정된 호출 시간을 포함한 순차 실행 recipe 비용이다. batch 시간은 한 번만 세고 main 비율로 배분한다. 모델 다운로드·적재·프로세스 시작은 제외하며 stage wall·적재 시간·실제 새 호출량은 results.json에 별도로 보존한다. 공유 전처리 비용은 각 solver를 독립 실행할 때의 비교표에 각각 청구했다.

## Paired 비교

| Solver | 조건 − 기준 | 차이 | Item bootstrap 95% CI | 회복 / 회귀 |
| --- | --- | ---: | --- | ---: |
| 8B | easyocr_cuda − O | +7.92pp | [+1.67, +15.00]pp | 30 / 11 |
| 8B | easyocr_cuda − VLM_inventory | +1.25pp | [-1.67, +4.58]pp | 8 / 5 |
| 8B | easyocr_cuda − EasyOCR_CPU | +0.83pp | [+0.00, +2.50]pp | 2 / 0 |
| 8B | ppocrv5_cuda − O | +8.33pp | [+2.08, +15.42]pp | 29 / 9 |
| 8B | ppocrv5_cuda − VLM_inventory | +1.67pp | [-0.83, +4.17]pp | 6 / 2 |
| 8B | ppocrv5_cuda − EasyOCR_CPU | +1.25pp | [-1.67, +4.17]pp | 6 / 3 |
| 4B | easyocr_cuda − O | +1.25pp | [-5.00, +9.59]pp | 19 / 16 |
| 4B | easyocr_cuda − VLM_inventory | -1.67pp | [-5.83, +2.92]pp | 7 / 11 |
| 4B | easyocr_cuda − EasyOCR_CPU | +0.83pp | [+0.00, +2.50]pp | 2 / 0 |
| 4B | ppocrv5_cuda − O | +1.25pp | [-4.17, +8.33]pp | 20 / 17 |
| 4B | ppocrv5_cuda − VLM_inventory | -1.67pp | [-5.42, +1.67]pp | 3 / 7 |
| 4B | ppocrv5_cuda − EasyOCR_CPU | +0.83pp | [-2.08, +3.75]pp | 7 / 5 |

## GUI 언어별

| Solver | 조건 | EN /60 | ZH /60 | TH /60 | RU /60 |
| --- | --- | ---: | ---: | ---: | ---: |
| 8B | easyocr_cuda | 46 | 48 | 41 | 46 |
| 8B | ppocrv5_cuda | 47 | 47 | 42 | 46 |
| 4B | easyocr_cuda | 53 | 46 | 29 | 49 |
| 4B | ppocrv5_cuda | 53 | 45 | 32 | 47 |

OCR 생성 성공·문자열 중복률은 OCR 정확도가 아니다. 빈 결과·OCR 실패·추출/정렬 fallback은 분모에서 제외하지 않는다. 이 개발 집합은 이미 반복 관찰했으며 독립 검증 결과로 해석하지 않는다.

미완료: 없음
